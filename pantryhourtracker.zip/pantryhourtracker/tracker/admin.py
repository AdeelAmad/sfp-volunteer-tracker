from django.contrib import admin
from .models import volunteer_hour

# Register your models here.
admin.site.register(volunteer_hour)